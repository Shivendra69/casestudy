package dao;

import entity.*;
import exception.*;

import java.util.List;

public interface IJobBoardDAO {
        void initializeDatabase() throws DatabaseConnectionException;
            void insertJobListing(JobListing job) throws DatabaseConnectionException;
                void insertCompany(Company company) throws DatabaseConnectionException;
                    void insertApplicant(Applicant applicant) throws DatabaseConnectionException, InvalidEmailFormatException;
                        void insertJobApplication(JobApplication application) throws DatabaseConnectionException, ApplicationDeadlineException;
                            List<JobListing> getJobListings() throws DatabaseConnectionException;
                                List<Company> getCompanies() throws DatabaseConnectionException;
                                    List<Applicant> getApplicants() throws DatabaseConnectionException;
                                        List<JobApplication> getApplicationsForJob(int jobID) throws DatabaseConnectionException;
                                            double calculateAverageSalary() throws DatabaseConnectionException, NegativeSalaryException;
                                                List<JobListing> getJobsBySalaryRange(double minSalary, double maxSalary) throws DatabaseConnectionException;
}
